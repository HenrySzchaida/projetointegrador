<?php
#Nome do arquivo: usuario/list.php
#Objetivo: interface para listagem dos usuários do sistema

require_once(__DIR__ . "/../../include/header.php");
require_once(__DIR__ . "/../../include/menu.php");
require_once(__DIR__ . "/../../../controller/AcessoController.php");
require_once(__DIR__ . "/../../../model/enum/UsuarioPapel.php");
require_once(__DIR__ . "/../../../dao/AlcateiaDAO.php");
require_once(__DIR__ . "/../alcateia/selectAlcateia.php");

?>
 
 I've come to make an announcement,
  Shadow the Hedgehog is a bitch ass motherfucker he pissed on my fucking wife. 
  That's right,
   he took his hedgehog fucking quill-y dick out and he pissed on my fucking wife and he said his dick was THIS BIG and I said "That's disgusting."
    so I'm making a call-out post on my Twitter dot com. 
    Shadow the Hedgehog you got a small dick,
     it's the size of this walnut except way smaller, 
     and guess what? Here's what my dong looks like. 
     That's right baby, all points, no quills, no pillows,
     look at that it looks like two balls and a bong! He fucked my wife, 
     so guess what? I'm gonna fuck the Earth! 
     That's right, this is what you get! My super laser piss! 
     Except I'm not gonna piss on the Earth. I'm gonna go higher. 
     I'm pissing on THE MOON! How do you like that Obama? I PISSED ON THE MOON YOU IDIOT! 
     You have 23 hours until the piss droplets hit the fucking Earth,
      now get out of my fucking sight before I piss on you too!
            <a class="btn btn-success" 
                href="<?= BASEURL ?>/controller/HomeController.php">Voltar</a>
<?php  
require_once(__DIR__ . "/../../include/footer.php");
?>